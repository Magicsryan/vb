﻿Public Class Form2
    Sub childForm(ByVal panel As Form)
        Panel1.Controls.Clear()
        panel.TopLevel = False

        Panel1.Controls.Add(panel)
        panel.Show()
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        childForm(FormKuning)
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        childForm(FormMerah)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        childForm(FormHijau)
    End Sub
End Class